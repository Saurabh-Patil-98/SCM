const Order = () => {
  return <div className="title"> Fees</div>;
};

export default Order;
