const Messages = () => {
  return <div className="title"> Messages</div>;
};

export default Messages;
