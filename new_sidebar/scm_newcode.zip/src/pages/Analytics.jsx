const Analytics = () => {
  return <div className="title"> Time table</div>;
};

export default Analytics;
